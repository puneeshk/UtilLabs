import HomeTemplate from '../../templates/home/home'

const Home = () => {
    return (
        <HomeTemplate />
    )
}

export default Home