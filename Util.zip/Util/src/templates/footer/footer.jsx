import { Container } from '@mui/material'
import Grid from '@mui/material/Grid2'
import { AuthorizedCloudReseller, Logo, SalesforcePartner } from '../../helpers/constant/imageUrl'
import CallIcon from '@mui/icons-material/Call';
import EmailIcon from '@mui/icons-material/Email';
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import XIcon from '@mui/icons-material/X';
import InstagramIcon from '@mui/icons-material/Instagram';
import './footer.scss'

const FooterTemplate = ({}) => {
    return (
        <div className="footer">
            <Container className='container'>
                <Grid container justifyContent="space-between">
                    <Grid size={{ xs: 12, md: 3 }}>
                        <img src={Logo} alt='' className='logo' /> 
                        <div className='mt-6'>
                            <img src={SalesforcePartner} alt='' className='mr-5' /> 
                            <img src={AuthorizedCloudReseller} alt='' /> 
                        </div>
                    </Grid>
                    <Grid size={{ xs: 12, md: 1 }}>
                        <ul>
                            <li>
                                <a href=''>
                                    Home
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Careers
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    About Us
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Contact Us
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Blogs
                                </a>
                            </li>
                        </ul>
                    </Grid>
                    <Grid size={{ xs: 12, md: 1 }}>
                        <ul>
                            <li>
                                <a href=''>
                                    Products
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Industries
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Solutions
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Services
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Technology
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Case Studies
                                </a>
                            </li>
                        </ul>
                    </Grid>
                    <Grid size={{ xs: 12, md: 2 }}>
                        <ul>
                            <li>
                                <a href=''>
                                    Privacy Policy
                                </a>
                            </li>
                            <li>
                                <a href=''>
                                    Terms & Conditions
                                </a>
                            </li>
                        </ul>
                    </Grid>
                    <Grid size={{ xs: 12, md: 2.5 }}>
                        <ul className='contact'>
                            <li>
                                <a href=''>
                                    <CallIcon className='mr-4' /> +91 99107 70310
                                </a>
                            </li>
                            <li className='mt-2'>
                                <a href=''>
                                    <EmailIcon className='mr-4' /> info@utilitarianlabs.com
                                </a>
                            </li>
                        </ul>
                        <h5>
                            Follow us on
                        </h5>
                        <div className='social-icon'>
                            <a href=''>
                                <FacebookIcon />
                            </a>
                            <a href=''>
                                <XIcon />
                            </a>
                            <a href=''>
                                <LinkedInIcon />
                            </a>
                            <a href=''>
                                <InstagramIcon />
                            </a>
                        </div>
                    </Grid>
                </Grid>      
                <div className='copy-right'>
                    Copyright &copy; 2024 Utilitarian Labs Pvt. Ltd. All Rights Reserved.
                </div>    
            </Container>
        </div>
    )
} 

export default FooterTemplate