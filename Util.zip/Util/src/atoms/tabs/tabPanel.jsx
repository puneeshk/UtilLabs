const AtomTabPanel = (props) => {
    const { children, value, index, id = 'simple', ...other } = props

    return (
        <div
            role="tabPanel"
            hidden={value !== index}
            id={`${id}-tabPanel-${index}`}
            aria-labelledby={`${id}-tab-${index}`}
            {...other}
        >
            {value === index && <div>{children}</div>}
        </div>

    )
}

export default AtomTabPanel