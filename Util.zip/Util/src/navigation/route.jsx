import React, { lazy } from 'react'
import { Routes, Route } from "react-router-dom"
import Home from '../page/home/home'

const RootRouter = () => {
    return (
        <React.Fragment>
            <Routes>
                <Route path="/" element={<Home />} />
            </Routes>
        </React.Fragment>
    )
}

export default RootRouter